from setuptools import setup, find_packages

setup(
    name = "src",
    version = "0.0.1",
    description = "Wine Quality Package",
    author = "Nonso Alumona",
    packages = find_packages(),
    license = "Apache 2.0"
)