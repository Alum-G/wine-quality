def test_pretend():
    a = 50
    b = 60
    assert a!=b